import scipy.io 
import numpy as np


########## Requirements ######
def req1(transactions):    
    return None
 
def req2(products):
    return None

def req3(transactions, products):
    return None

def req4(transactions, products):
    return None 

def req5(history, k):
    return None

def req6(transactions, history, k):
    return None

def req7(transactions, history):
    return None

def req8(transactions, history, k):
    return None

def req9(transactions, history, products):
    return None

def req10(history, transactions, products, k):
    return None
