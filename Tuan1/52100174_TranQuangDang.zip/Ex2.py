new_dict={1: 'foo', 2: 'bar', 3: 'baz', 4: 'qux',5:'quy'}
# a list
new_list=list(new_dict.values())
# b set
new_set=set(new_dict.values())
# c tuple
new_tuple=tuple(new_dict.values())