new_dict={"A":5,"B":6,"C":7,"D":8}

# a
print(new_dict["A"])
print(new_dict)

# b
new_dict["B"] =100
print(new_dict)


# c
del new_dict["B"]
print(new_dict)


# d
new_dict["E"] =10;
print(new_dict)
