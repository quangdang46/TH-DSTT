import numpy as np
x= np.array([1,3,5,2,9])
print(x[2])
y= np.array([-1,3,15,27.29])
print(y[2])
