from numpy import logspace
n=int(input())
a = logspace(1, n, n)
