import numpy as np
x=[1,2,3]
y=[98,12,33]
z= np.concatenate((x,y), axis =0)