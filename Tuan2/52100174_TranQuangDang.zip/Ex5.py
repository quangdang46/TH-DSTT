import numpy as np
x=[1,2,3]
y=[4,5,6]
z=np.vstack((x,y))


