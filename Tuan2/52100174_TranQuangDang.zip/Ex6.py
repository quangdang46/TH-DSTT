import numpy as np
x=np.array([0 ,2, 4, 6, 8, 10, 12, 14, 16, 18, 20])
print(x[5])
print(x[-5])
print(x[[0,3,-1]])
print(x[0:8:2])
print(x[1:12:2])
print(x[0:13:2])

