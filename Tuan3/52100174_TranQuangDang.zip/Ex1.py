#Ex1
import numpy as np
x=[1,2,3,4,5]
b=[1,2,3,4,5,6]
A=np.array([x]*5).T
B=np.array([b]*6)
C=np.array(range(1,31)).reshape(5,6).T
D=np.array(range(1,26)).reshape(5,5)