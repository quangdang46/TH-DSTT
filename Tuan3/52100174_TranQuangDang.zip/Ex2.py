# Ex2
import numpy as np

from Ex1 import C
a,b=map(int,input().split())
z=np.random.randint(a,b,size=(5,6))
