# Ex3
import numpy as np
A=np.array(range(1,10)).reshape(3,3)
print(np.fliplr(A))
# B=np.copy(A)
# B[:,[0,2]]=B[:,[2,0]]
# print(B)