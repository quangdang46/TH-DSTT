# Ex4
import numpy as np
A=np.array(range(1,10)).reshape(3,3)
# B=np.copy(A)
# C=np.copy(A)
# print(A[::-1,:])
# B[[2,0],:]=B[[0,2],:]
# print(np.flip(C, axis = 0 ))
# print(A[::-1,:])
print(np.flipud(A))
