# Ex7
import numpy as np
A=np.array([[2,7,9,7],[3,1,5,6],[8,1,2,5]])
B=A[:,::2]
C=A[1::2,:]
A=A.reshape(4,3)